"""Google Cloud Tools."""

from langchain_community.tools.google_cloud.texttospeech import (
    GoogleCloudTextToSpeechTool,
)

__all__ = ["GoogleCloudTextToSpeechTool"]
