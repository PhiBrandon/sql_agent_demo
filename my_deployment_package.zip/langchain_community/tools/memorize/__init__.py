"""Unsupervised learning based memorization."""

from langchain_community.tools.memorize.tool import Memorize

__all__ = ["Memorize"]
