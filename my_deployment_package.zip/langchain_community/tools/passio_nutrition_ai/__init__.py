"""Passio Nutrition AI API toolkit."""

from langchain_community.tools.passio_nutrition_ai.tool import NutritionAI

__all__ = ["NutritionAI"]
