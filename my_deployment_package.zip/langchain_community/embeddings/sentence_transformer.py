"""HuggingFace sentence_transformer embedding models."""
from langchain_community.embeddings.huggingface import HuggingFaceEmbeddings

SentenceTransformerEmbeddings = HuggingFaceEmbeddings
